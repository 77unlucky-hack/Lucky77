# Lucky77 UI Demo

A harmless UIKit demo menu inspired by the supplied visual style.

## Included
- Black / white / dark-purple / purple theme
- Rounded launcher button with `77`
- `Lucky77` title
- First-open intro animation (~2 seconds total)
- Live FPS label using `CADisplayLink`
- Clickable navigation
- Clickable visual demo toggles
- Sliders
- Smooth menu open/close animations
- No game logic
- No hooks
- No process injection
- No memory modification
- No anti-cheat logic

## Library API

```objc
#import "Lucky77Menu.h"

Lucky77PresentMenu(self);
```

Or embed the returned controller yourself:

```objc
UIViewController *menu = Lucky77CreateMenuViewController();
```

## Build a `.dylib`

The provided `build_ios_dylib.sh` must be run on macOS with Xcode installed because Apple's iOS SDK and linker are required:

```bash
chmod +x build_ios_dylib.sh
./build_ios_dylib.sh
```

Output:
`build/Lucky77.dylib`

This project intentionally exposes a normal app-facing API. It does not auto-load itself into other apps.
