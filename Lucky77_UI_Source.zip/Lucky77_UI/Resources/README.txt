Place your custom 77 logo here if desired.
The current demo renders the text “77” in UIKit, so no image asset is required.
