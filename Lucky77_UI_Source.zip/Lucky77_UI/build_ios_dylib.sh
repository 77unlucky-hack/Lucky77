#!/bin/bash
set -euo pipefail

# Run on macOS with Xcode installed.
# This builds a normal reusable iOS dynamic library for use by an app you own.
SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
CLANG="$(xcrun --find clang)"

mkdir -p build

"$CLANG" \
  -fobjc-arc \
  -isysroot "$SDK" \
  -miphoneos-version-min=15.0 \
  -arch arm64 \
  -dynamiclib \
  -framework UIKit \
  -framework QuartzCore \
  Sources/Lucky77Theme.m \
  Sources/Lucky77Menu.mm \
  -install_name @rpath/Lucky77.dylib \
  -o build/Lucky77.dylib

echo "Built: build/Lucky77.dylib"
