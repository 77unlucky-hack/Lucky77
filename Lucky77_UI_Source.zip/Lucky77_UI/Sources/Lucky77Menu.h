#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// Presents the Lucky77 demo UI from a view controller owned by your app.
/// This library contains visual demo controls only and no game/modification logic.
FOUNDATION_EXPORT void Lucky77PresentMenu(UIViewController *presenter);

/// Returns the reusable menu view controller if you want to embed it yourself.
FOUNDATION_EXPORT UIViewController *Lucky77CreateMenuViewController(void);

NS_ASSUME_NONNULL_END
