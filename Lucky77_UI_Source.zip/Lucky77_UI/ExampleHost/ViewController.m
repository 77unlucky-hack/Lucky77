#import <UIKit/UIKit.h>
#import "Lucky77Menu.h"

@interface ViewController : UIViewController
@end

@implementation ViewController
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"Open Lucky77 UI" forState:UIControlStateNormal];
    button.frame = CGRectMake(40, 100, 220, 50);
    [button addTarget:self action:@selector(openMenu) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}
- (void)openMenu {
    Lucky77PresentMenu(self);
}
@end
